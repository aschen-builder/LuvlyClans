﻿# LUVLY CLANS

## PREREQS

You must have BepInEx, Jotunn, and Ehanced Progress Tracker installed.

## INSTALLATION

Both the client and the server need to have this mod installed. Simply install with your preferred mod manager, or manually download, unzip, and copy `LuvlyClans.dll` to `/BepInEx/plugins`.

## CONFIGURATION

This mod relies on the Tribe configuration files of Enhanced Progress Tracker.

You can view the configuration setup here:

https://github.com/ASharpPen/Valheim.EnhancedProgressTracker#configuration
